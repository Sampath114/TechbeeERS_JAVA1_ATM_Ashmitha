
const sign_in_btn = document.querySelector("#sign-in-btn");

const sign_up_btn = document.querySelector("#sign-up-btn");

const container = document.querySelector(".container");




sign_up_btn.addEventListener("click", () => {

  container.classList.add("sign-up-mode");

});




sign_in_btn.addEventListener("click", () => {

  container.classList.remove("sign-up-mode");

});

try{
    function validateform(){  
    var name=document.myform.name.value;  
    var password=document.myform.password.value;  
    
    
    if (name=="" || password==""){  
      alert("Name or password can't be blank");  
      return false;  
    }else if(password.length<6){  
      alert("Password must be at least 6 characters long.");  
      return false;  
      }  
    else{
      return true;
    }
    }
  }catch(er){
    console.log(er.message);
  }
  

function validatepass()  
{  
var firstpassword=document.form1.password1.value;  
var secondpassword=document.form1.password2.value; 

if(firstpassword==secondpassword){  
return true;  
}  
else{  
alert("password must be same!");  
return false;  
}  



}  

